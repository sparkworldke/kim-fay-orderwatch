<?php

namespace App\Services\Reports;

use App\Models\DailyReportConfig;
use App\Models\DailyReportRun;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;

class DailyReportRunnerService
{
    public function __construct(
        private readonly DailyExecutiveReportService $report,
        private readonly DailyManagementInsightService $insights,
        private readonly DailyReportMailerService $mailer,
    ) {}

    public function shouldRunScheduled(DailyReportConfig $config, ?Carbon $now = null): bool
    {
        if (! $config->is_enabled) {
            return false;
        }

        $now = ($now ?? now())->timezone($config->timezone);
        $sendTime = substr((string) $config->send_time, 0, 5);

        if ($now->format('H:i') !== $sendTime) {
            return false;
        }

        $reportDate = $now->copy()->subDay()->toDateString();

        return ! $this->hasSuccessfulSend($config->id, $reportDate);
    }

    /**
     * @param  bool  $force  When true, regenerate and resend even if already completed for the report date.
     * @param  bool  $ignoreSendTimeWindow  When true, skip the config send_time window check
     *                                       (used by the fixed Tue–Sat cron which has its own schedule).
     *                                       Does NOT bypass the already-sent guard unless $force is also true.
     */
    public function run(
        DailyReportConfig $config,
        string $trigger = 'scheduler',
        bool $force = false,
        ?Carbon $asOf = null,
        ?array $overrideSendTo = null,
        ?array $overrideCc = null,
        bool $ignoreSendTimeWindow = false,
    ): DailyReportRun {
        $started = hrtime(true);
        $timezone = $config->timezone ?: 'Africa/Nairobi';
        $asOf = ($asOf ?? now())->timezone($timezone);
        $reportDate = $asOf->copy()->subDay()->startOfDay();
        $reportDateKey = $reportDate->toDateString();

        // Soft pre-check (fast path). The authoritative check runs inside the lock.
        if (! $force && $this->hasSuccessfulSend($config->id, $reportDateKey)) {
            return $this->skippedRun(
                $config,
                $reportDate,
                'Report already sent for this date. Use --force to regenerate and resend.',
            );
        }

        if (
            ! $force
            && ! $ignoreSendTimeWindow
            && $trigger === 'scheduler'
            && ! $this->shouldRunScheduled($config, $asOf)
        ) {
            return $this->skippedRun(
                $config,
                $reportDate,
                'Not scheduled to run at this time or already sent.',
            );
        }

        $lock = Cache::lock($this->lockKey($config->id, $reportDateKey), 300);
        if (! $lock->get()) {
            Log::info('daily_report_skipped_lock', [
                'report_date' => $reportDateKey,
                'trigger' => $trigger,
            ]);

            return $this->skippedRun(
                $config,
                $reportDate,
                'Another daily report run is already in progress for this date.',
                deliveryStatus: 'skipped',
            );
        }

        try {
            // Authoritative idempotency: re-check under lock so concurrent schedule:run
            // processes cannot both send after both passed the soft pre-check.
            if (! $force && $this->hasSuccessfulSend($config->id, $reportDateKey)) {
                Log::info('daily_report_skipped_already_sent_under_lock', [
                    'report_date' => $reportDateKey,
                    'trigger' => $trigger,
                ]);

                return $this->skippedRun(
                    $config,
                    $reportDate,
                    'Report already sent for this date (detected under lock).',
                    deliveryStatus: 'skipped',
                );
            }

            $run = DailyReportRun::create([
                'report_config_id' => $config->id,
                'report_date' => $reportDate,
                'started_at' => now(),
                'status' => 'running',
            ]);

            try {
                $payload = $this->report->buildPayload($asOf, $timezone);

                $aiInsights = $config->include_ai_insights
                    ? $this->insights->generate($payload, true)
                    : ['ai_status' => 'disabled', 'executive_summary' => '', 'performance_commentary' => '', 'improvements' => []];
                $payload['insights'] = $aiInsights;

                $sendConfig = clone $config;
                if ($overrideSendTo !== null || $overrideCc !== null) {
                    $sendTo = $overrideSendTo ?? $config->replyTo();
                    $cc = $overrideCc ?? array_values(array_diff($config->recipients(), $sendTo));
                    $sendConfig->reply_to_json = $sendTo;
                    $sendConfig->recipients_json = array_values(array_unique(array_merge($sendTo, $cc)));
                }

                $delivery = $this->mailer->send($run, $sendConfig, $payload, $aiInsights);
                $duration = (int) ((hrtime(true) - $started) / 1_000_000);

                $status = match ($delivery['delivery_status']) {
                    'sent' => 'completed',
                    'partial' => 'partial',
                    'skipped' => 'completed',
                    default => 'failed',
                };

                $run->update([
                    'completed_at' => now(),
                    'sent_at' => in_array($delivery['delivery_status'], ['sent', 'partial'], true) ? now() : null,
                    'status' => $status,
                    'ai_status' => $aiInsights['ai_status'] ?? 'unknown',
                    'delivery_status' => $delivery['delivery_status'],
                    'recipient_count' => $delivery['sent_count'],
                    'duration_ms' => $duration,
                    'payload_json' => $payload,
                    'error_summary' => $delivery['errors'] !== [] ? implode("\n", $delivery['errors']) : null,
                ]);

                $fresh = $run->fresh('deliveryLogs');
                Log::info('daily_report_run_finished', [
                    'run_id' => $fresh?->id,
                    'report_date' => $reportDateKey,
                    'trigger' => $trigger,
                    'status' => $fresh?->status,
                    'delivery_status' => $fresh?->delivery_status,
                    'recipient_count' => $fresh?->recipient_count,
                    'error_summary' => $fresh?->error_summary,
                ]);

                return $fresh;
            } catch (Throwable $e) {
                $duration = (int) ((hrtime(true) - $started) / 1_000_000);
                $run->update([
                    'completed_at' => now(),
                    'status' => 'failed',
                    'ai_status' => 'failed',
                    'delivery_status' => 'failed',
                    'duration_ms' => $duration,
                    'error_summary' => $e->getMessage(),
                ]);

                Log::error('daily_report_run_failed', [
                    'run_id' => $run->id,
                    'report_date' => $reportDateKey,
                    'trigger' => $trigger,
                    'error' => $e->getMessage(),
                ]);

                return $run->fresh('deliveryLogs');
            }
        } finally {
            $lock->release();
        }
    }

    public function resendLast(DailyReportConfig $config, ?array $overrideSendTo = null, ?array $overrideCc = null): ?DailyReportRun
    {
        $last = DailyReportRun::query()
            ->where('report_config_id', $config->id)
            ->whereNotNull('payload_json')
            ->whereIn('status', ['completed', 'partial'])
            ->latest('report_date')
            ->first();

        if (! $last || ! is_array($last->payload_json)) {
            return null;
        }

        $started = hrtime(true);
        $run = DailyReportRun::create([
            'report_config_id' => $config->id,
            'report_date' => $last->report_date,
            'started_at' => now(),
            'status' => 'running',
            'payload_json' => $last->payload_json,
        ]);

        try {
            $payload = $last->payload_json;
            $insights = $payload['insights'] ?? $this->insights->generate($payload, $config->include_ai_insights);

            $sendConfig = clone $config;
            if ($overrideSendTo !== null || $overrideCc !== null) {
                $sendTo = $overrideSendTo ?? $config->replyTo();
                $cc = $overrideCc ?? array_values(array_diff($config->recipients(), $sendTo));
                $sendConfig->reply_to_json = $sendTo;
                $sendConfig->recipients_json = array_values(array_unique(array_merge($sendTo, $cc)));
            }

            $delivery = $this->mailer->send($run, $sendConfig, $payload, $insights);
            $duration = (int) ((hrtime(true) - $started) / 1_000_000);

            $run->update([
                'completed_at' => now(),
                'sent_at' => in_array($delivery['delivery_status'], ['sent', 'partial'], true) ? now() : null,
                'status' => $delivery['delivery_status'] === 'sent' ? 'completed' : ($delivery['delivery_status'] === 'partial' ? 'partial' : 'failed'),
                'ai_status' => $insights['ai_status'] ?? 'reused',
                'delivery_status' => $delivery['delivery_status'],
                'recipient_count' => $delivery['sent_count'],
                'duration_ms' => $duration,
                'error_summary' => $delivery['errors'] !== [] ? implode("\n", $delivery['errors']) : null,
            ]);

            return $run->fresh('deliveryLogs');
        } catch (Throwable $e) {
            $run->update([
                'completed_at' => now(),
                'status' => 'failed',
                'delivery_status' => 'failed',
                'error_summary' => $e->getMessage(),
            ]);

            return $run->fresh('deliveryLogs');
        }
    }

    public function hasSuccessfulSend(int $configId, string $reportDate): bool
    {
        return DailyReportRun::query()
            ->where('report_config_id', $configId)
            ->whereDate('report_date', $reportDate)
            ->whereIn('status', ['completed', 'partial'])
            ->whereIn('delivery_status', ['sent', 'partial'])
            ->exists();
    }

    private function lockKey(int $configId, string $reportDate): string
    {
        return "daily-report:{$configId}:{$reportDate}";
    }

    private function skippedRun(
        DailyReportConfig $config,
        Carbon $reportDate,
        string $reason,
        ?string $deliveryStatus = null,
    ): DailyReportRun {
        return DailyReportRun::create([
            'report_config_id' => $config->id,
            'report_date' => $reportDate,
            'started_at' => now(),
            'completed_at' => now(),
            'status' => 'skipped',
            'delivery_status' => $deliveryStatus,
            'error_summary' => $reason,
            'duration_ms' => 0,
        ]);
    }
}
