<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AcumaticaRoute;
use App\Models\AcumaticaSalesOrder;
use App\Models\AcumaticaShippingZone;
use App\Models\User;
use App\Services\Admin\SalesOrderLineFulfillmentDeriver;
use App\Services\Operations\OperationsCatalogResolver;
use App\Services\Team\CustomerAttributionService;
use App\Services\Team\AccessTierService;
use App\Support\DataScope;
use App\Support\SalesConsultantScope;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function __construct(
        private readonly OperationsCatalogResolver $catalogResolver,
    ) {
    }

    public function filterOptions(Request $request): JsonResponse
    {
        $user = $request->user();
        $isSalesConsultant = app(AccessTierService::class)
            ->isExclusivelySalesConsultant($user);

        $visibleOrders = DataScope::applyOrderScope(
            AcumaticaSalesOrder::query()->salesOrdersOnly(),
            $user,
        );
        $this->applyLegacyConsultantFallback($visibleOrders, $user);

        $repCodes = (clone $visibleOrders)
            ->whereNotNull('sales_consultant_rep_code')
            ->where('sales_consultant_rep_code', '!=', '')
            ->distinct()
            ->pluck('sales_consultant_rep_code')
            ->map(fn ($code) => strtoupper(trim((string) $code)))
            ->filter()
            ->unique()
            ->values();

        $consultants = User::query()
            ->where('is_active', true)
            ->whereNotNull('rep_code')
            ->whereIn(DB::raw('UPPER(rep_code)'), $repCodes->all())
            ->orderBy('name')
            ->get(['id', 'name', 'rep_code'])
            ->map(fn (User $consultant) => [
                'id' => $consultant->id,
                'name' => $consultant->name,
                'rep_code' => strtoupper(trim((string) $consultant->rep_code)),
            ])
            ->values();

        // Distinct customers visible in scoped SO history (for multi-select filter).
        // Prefer catalog name from acumatica_customers — SO.customer_name is often blank/ID-like.
        $customerIds = (clone $visibleOrders)
            ->whereNotNull('customer_acumatica_id')
            ->where('customer_acumatica_id', '!=', '')
            ->distinct()
            ->orderBy('customer_acumatica_id')
            ->limit(3000)
            ->pluck('customer_acumatica_id')
            ->map(fn ($id) => (string) $id)
            ->values();

        $orderNames = (clone $visibleOrders)
            ->whereIn('customer_acumatica_id', $customerIds->all())
            ->whereNotNull('customer_name')
            ->where('customer_name', '!=', '')
            ->selectRaw('customer_acumatica_id, MAX(TRIM(customer_name)) as name')
            ->groupBy('customer_acumatica_id')
            ->pluck('name', 'customer_acumatica_id');

        $catalogNames = $this->catalogResolver->namesForCustomerIds($customerIds->all());

        $customers = $customerIds
            ->map(function (string $id) use ($catalogNames, $orderNames) {
                $catalog = $catalogNames->get($id);
                $fromCatalog = is_string($catalog) ? trim($catalog) : '';
                $fromOrder = trim((string) ($orderNames->get($id) ?? ''));
                // Never surface bare customer ID as the display label when a real name exists.
                $name = $fromCatalog !== '' && ! $this->looksLikeCustomerId($fromCatalog)
                    ? $fromCatalog
                    : ($fromOrder !== '' && ! $this->looksLikeCustomerId($fromOrder)
                        ? $fromOrder
                        : ($fromCatalog !== '' ? $fromCatalog : ($fromOrder !== '' ? $fromOrder : $id)));

                return [
                    'id' => $id,
                    'name' => $name,
                ];
            })
            ->sortBy(fn (array $row) => mb_strtolower($row['name']), SORT_NATURAL)
            ->values();

        return response()->json([
            'brands' => DB::table('acumatica_inventory_items')
                ->whereNotNull('brand')
                ->where('brand', '!=', '')
                ->distinct()
                ->orderBy('brand')
                ->pluck('brand')
                ->values(),
            'segments' => [
                ['id' => 'KP', 'name' => 'KP'],
                ['id' => 'CS', 'name' => 'Consumer Sales'],
            ],
            'statuses' => [
                'Open', 'Pending Approval', 'Shipping', 'Completed',
                'Rejected', 'On Hold', 'Credit Hold',
            ],
            'customers' => $customers,
            'consultants' => $isSalesConsultant
                ? $consultants->where('id', $user->id)->values()
                : $consultants,
            'consultant_locked' => $isSalesConsultant,
            'current_consultant' => $isSalesConsultant ? [
                'id' => $user->id,
                'name' => $user->name,
                'rep_code' => strtoupper(trim((string) $user->rep_code)),
            ] : null,
        ]);
    }

    /** Return status-broken-down KPI counts for the given date range (excludes Goods Lost in Transit). */
    public function kpis(Request $request): JsonResponse
    {
        $dateFrom = $request->input('date_from', now()->startOfMonth()->toDateString());
        $dateTo   = $request->input('date_to',   now()->toDateString());
        $user = $request->user();

        $counts = $this->statusCounts($dateFrom, $dateTo, $user, $request, excludeSpecialCustomers: true);
        $allCounts = $this->statusCounts($dateFrom, $dateTo, $user, $request, excludeSpecialCustomers: false);
        $gltCounts = $this->statusCounts($dateFrom, $dateTo, $user, $request, onlyGoodsLostInTransit: true);

        return response()->json(array_merge($counts, [
            'date_from' => $dateFrom,
            'date_to'   => $dateTo,
            // Total SO calculation: all SO vs dashboard (excl. GLT) vs GLT tab.
            'so_totals' => [
                'all_so' => $allCounts['total'],
                'dashboard_so' => $counts['total'],
                'goods_lost_in_transit_so' => $gltCounts['total'],
                'excluded_customer_ids' => $this->excludedCustomerIds(),
                'formula' => 'All SO = Dashboard SO + Goods Lost in Transit SO',
                'calculation' => sprintf(
                    '%d = %d + %d',
                    $allCounts['total'],
                    $counts['total'],
                    $gltCounts['total'],
                ),
            ],
            'goods_lost_in_transit' => [
                'customer_id' => $this->goodsLostInTransitCustomerId(),
                'label' => $this->goodsLostInTransitLabel(),
                'total' => $gltCounts['total'],
                'statuses' => $gltCounts,
            ],
        ]));
    }

    /**
     * Goods Lost in Transit tab — SOs for the dedicated customer (default CUST102641).
     */
    public function goodsLostInTransit(Request $request): JsonResponse
    {
        $dateFrom = $request->input('date_from', now()->startOfMonth()->toDateString());
        $dateTo = $request->input('date_to', now()->toDateString());
        $customerId = $this->goodsLostInTransitCustomerId();
        $user = $request->user();

        $base = DataScope::applyOrderScope(
            AcumaticaSalesOrder::query()->salesOrdersOnly(),
            $user,
        )
            ->where('customer_acumatica_id', $customerId)
            ->whereDate('order_date', '>=', $dateFrom)
            ->whereDate('order_date', '<=', $dateTo);

        $statusRows = (clone $base)
            ->select([DB::raw('status'), DB::raw('COUNT(*) as cnt')])
            ->groupBy('status')
            ->pluck('cnt', 'status')
            ->mapWithKeys(fn ($cnt, $status) => [strtolower(trim($status ?? 'unknown')) => (int) $cnt])
            ->toArray();

        $total = (int) (clone $base)->count();
        $orderTotalSum = (float) (clone $base)->sum('order_total');

        $orders = (clone $base)
            ->withSum('lines as total_qty', 'order_qty')
            ->orderByDesc('order_date')
            ->orderByDesc('acumatica_order_nbr')
            ->limit(500)
            ->get([
                'id',
                'acumatica_order_nbr',
                'customer_name',
                'customer_acumatica_id',
                'order_total',
                'currency_id',
                'status',
                'order_date',
            ]);

        $customerNames = $this->catalogResolver->namesForCustomerIds([$customerId]);
        $customerName = $this->catalogResolver->resolveCustomerName(
            $orders->first()?->customer_name,
            $customerId,
            $customerNames,
        ) ?? $this->goodsLostInTransitLabel();

        // All SO in range (same scope) for the calculation strip.
        $allSoTotal = (int) DataScope::applyOrderScope(
            AcumaticaSalesOrder::query()->salesOrdersOnly(),
            $user,
        )
            ->whereDate('order_date', '>=', $dateFrom)
            ->whereDate('order_date', '<=', $dateTo)
            ->count();

        $dashboardSoTotal = max(0, $allSoTotal - $total);

        return response()->json([
            'customer_id' => $customerId,
            'customer_name' => $customerName,
            'label' => $this->goodsLostInTransitLabel(),
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'total' => $total,
            'order_total_sum' => round($orderTotalSum, 2),
            'completed' => $statusRows['completed'] ?? 0,
            'shipping' => $statusRows['shipping'] ?? 0,
            'pending_approval' => $statusRows['pending approval'] ?? 0,
            'rejected' => $statusRows['rejected'] ?? 0,
            'on_hold' => ($statusRows['on hold'] ?? 0) + ($statusRows['credit hold'] ?? 0),
            'open' => $statusRows['open'] ?? 0,
            'so_totals' => [
                'all_so' => $allSoTotal,
                'dashboard_so' => $dashboardSoTotal,
                'goods_lost_in_transit_so' => $total,
                'formula' => 'All SO = Dashboard SO + Goods Lost in Transit SO',
                'calculation' => sprintf(
                    '%d = %d + %d',
                    $allSoTotal,
                    $dashboardSoTotal,
                    $total,
                ),
            ],
            'orders' => $orders->map(fn ($order) => [
                'id' => $order->id,
                'order_nbr' => $order->acumatica_order_nbr,
                'customer_acumatica_id' => $order->customer_acumatica_id,
                'customer_name' => $this->catalogResolver->resolveCustomerName(
                    $order->customer_name,
                    $order->customer_acumatica_id,
                    $customerNames,
                ),
                'amount' => round((float) $order->order_total, 2),
                'currency_id' => $order->currency_id,
                'quantity' => round((float) ($order->total_qty ?? 0), 4),
                'order_date' => $order->order_date?->toDateString(),
                'status' => $order->status,
            ])->values(),
        ]);
    }

    /** Orders for a dashboard status bucket (used by expandable status accordions). */
    public function ordersByStatus(Request $request): JsonResponse
    {
        $dateFrom = $request->input('date_from', now()->startOfMonth()->toDateString());
        $dateTo   = $request->input('date_to', now()->toDateString());
        $statusKey = strtolower(trim((string) $request->input('status', '')));

        $statuses = match ($statusKey) {
            'open'             => ['Open'],
            'completed'        => ['Completed'],
            'shipping'         => ['Shipping'],
            'pending_approval' => ['Pending Approval'],
            'rejected'         => ['Rejected'],
            'on_hold'          => ['On Hold', 'Credit Hold'],
            default            => null,
        };

        if ($statuses === null) {
            return response()->json(['message' => 'Invalid status key.'], 422);
        }

        $orders = $this->applyDashboardFilters($this->excludeSpecialCustomers(
            DataScope::applyOrderScope(
                AcumaticaSalesOrder::query()->salesOrdersOnly(),
                $request->user(),
            ),
        ), $request, applyStatus: false)
            ->whereDate('order_date', '>=', $dateFrom)
            ->whereDate('order_date', '<=', $dateTo)
            ->whereIn('status', $statuses)
            ->withSum('lines as total_qty', 'order_qty')
            ->orderByDesc('order_date')
            ->orderByDesc('acumatica_order_nbr')
            ->limit(200)
            ->get([
                'id',
                'acumatica_order_nbr',
                'customer_name',
                'customer_acumatica_id',
                'order_total',
                'currency_id',
                'status',
                'order_date',
            ]);

        $customerNames = $this->catalogResolver->namesForCustomerIds(
            $orders->pluck('customer_acumatica_id')->filter()->unique()->values()->all(),
        );

        return response()->json([
            'status'     => $statusKey,
            'date_from'  => $dateFrom,
            'date_to'    => $dateTo,
            'count'      => $orders->count(),
            'orders'     => $orders->map(fn ($order) => [
                'id'                    => $order->id,
                'order_nbr'             => $order->acumatica_order_nbr,
                'customer_acumatica_id' => $order->customer_acumatica_id,
                'customer_name'         => $this->catalogResolver->resolveCustomerName(
                    $order->customer_name,
                    $order->customer_acumatica_id,
                    $customerNames,
                ),
                'amount'        => round((float) $order->order_total, 2),
                'currency_id'   => $order->currency_id,
                'quantity'      => round((float) ($order->total_qty ?? 0), 4),
                'order_date'    => $order->order_date?->toDateString(),
                'status'        => $order->status,
            ])->values(),
        ]);
    }

    /**
     * Zone routes accordion: returns shipping zones with their routes and
     * per-route order/shipment counts broken down by dashboard status buckets.
     */
    public function zoneRoutes(Request $request): JsonResponse
    {
        $dateFrom = $request->input('date_from', now()->startOfMonth()->toDateString());
        $dateTo   = $request->input('date_to',   now()->toDateString());
        $user     = $request->user();

        // -- Shipping zones (with their routes) --------------------------------
        $zones = AcumaticaShippingZone::query()
            ->orderBy('acumatica_id')
            ->get(['acumatica_id', 'description', 'name', 'region']);

        $routesByZone = AcumaticaRoute::query()
            ->orderBy('shipping_zone_id')
            ->orderBy('route_code')
            ->get(['route_code', 'route_name', 'shipping_zone_id', 'customer_zone'])
            ->groupBy('shipping_zone_id');

        // -- Order counts grouped by zone_id + route_code + status -------------
        // Join orders → customers to pick up route_code and shipping_zone_id.
        $rows = $this->excludeSpecialCustomers(
            DataScope::applyOrderScope(
                AcumaticaSalesOrder::salesOrdersOnly(),
                $user,
            ),
        )
            ->whereDate('acumatica_sales_orders.order_date', '>=', $dateFrom)
            ->whereDate('acumatica_sales_orders.order_date', '<=', $dateTo)
            ->join(
                'acumatica_customers as cust',
                'cust.acumatica_id',
                '=',
                'acumatica_sales_orders.customer_acumatica_id',
            )
            ->whereNotNull('cust.route_code')
            ->where('cust.route_code', '!=', '')
            ->select(
                'cust.shipping_zone_id',
                'cust.route_code',
                DB::raw('LOWER(TRIM(acumatica_sales_orders.status)) as status_key'),
                DB::raw('COUNT(*) as cnt'),
            )
            ->groupBy('cust.shipping_zone_id', 'cust.route_code', 'status_key')
            ->get();

        // Index the counts for fast lookup: [zone_id][route_code][status_key] = cnt
        $counts = [];
        foreach ($rows as $row) {
            $counts[$row->shipping_zone_id][$row->route_code][$row->status_key] = (int) $row->cnt;
        }

        // -- Assemble the response --------------------------------------------
        $zonesData = $zones->map(function ($zone) use ($routesByZone, $counts) {
            $zoneRoutes = ($routesByZone[$zone->acumatica_id] ?? collect())->map(function ($route) use ($counts, $zone) {
                $rc = $route->route_code;
                $sc = $counts[$zone->acumatica_id][$rc] ?? [];

                $total = array_sum($sc);

                return [
                    'route_code'        => $rc,
                    'route_name'        => $route->route_name,
                    'customer_zone'     => $route->customer_zone,
                    'total'             => $total,
                    'open'              => $sc['open']             ?? 0,
                    'pending_approval'  => $sc['pending approval'] ?? 0,
                    'shipping'          => $sc['shipping']         ?? 0,
                    'completed'         => $sc['completed']        ?? 0,
                    'rejected'          => $sc['rejected']         ?? 0,
                    'on_hold'           => ($sc['on hold'] ?? 0) + ($sc['credit hold'] ?? 0),
                    'back_order'        => $sc['back order']       ?? 0,
                ];
            })->values();

            $zoneTotal = $zoneRoutes->sum('total');

            return [
                'shipping_zone_id' => $zone->acumatica_id,
                'name'             => $zone->name ?? $zone->acumatica_id,
                'description'      => $zone->description,
                'region'           => $zone->region,
                'total'            => $zoneTotal,
                'routes'           => $zoneRoutes,
            ];
        });

        // Keep only zones that have at least one route (with or without orders).
        $zonesData = $zonesData->filter(fn ($z) => count($z['routes']) > 0)->values();

        return response()->json([
            'date_from' => $dateFrom,
            'date_to'   => $dateTo,
            'total'     => $zonesData->sum('total'),
            'zones'     => $zonesData,
        ]);
    }

    /** Daily trend data for the chart, optionally with previous-period comparison. */
    public function trend(Request $request): JsonResponse
    {
        $dateFrom = $request->input('date_from', now()->startOfMonth()->toDateString());
        $dateTo   = $request->input('date_to',   now()->toDateString());
        $compare  = $request->boolean('compare', false);

        $current = $this->dailyTrend($dateFrom, $dateTo, null, $request->user(), $request);

        $previous = null;
        if ($compare) {
            $days     = Carbon::parse($dateFrom)->diffInDays(Carbon::parse($dateTo)) + 1;
            $prevFrom = Carbon::parse($dateFrom)->subDays($days)->toDateString();
            $prevTo   = Carbon::parse($dateTo)->subDays($days)->toDateString();
            $previous = $this->dailyTrend($prevFrom, $prevTo, $prevFrom, $request->user(), $request);
        }

        return response()->json([
            'current'  => $current,
            'previous' => $previous,
        ]);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private function statusCounts(
        string $dateFrom,
        string $dateTo,
        ?User $user,
        Request $request,
        bool $excludeSpecialCustomers = true,
        bool $onlyGoodsLostInTransit = false,
    ): array {
        $base = $this->applyDashboardFilters(DataScope::applyOrderScope(
            AcumaticaSalesOrder::salesOrdersOnly(),
            $user,
        ), $request)
            ->whereDate('order_date', '>=', $dateFrom)
            ->whereDate('order_date', '<=', $dateTo);

        if ($onlyGoodsLostInTransit) {
            $base->where('customer_acumatica_id', $this->goodsLostInTransitCustomerId());
        } elseif ($excludeSpecialCustomers) {
            $base = $this->excludeSpecialCustomers($base);
        }

        $rows = (clone $base)
            ->select([DB::raw('status'), DB::raw('COUNT(*) as cnt')])
            ->groupBy('status')
            ->pluck('cnt', 'status')
            ->mapWithKeys(fn ($cnt, $status) => [strtolower(trim($status ?? 'unknown')) => (int) $cnt])
            ->toArray();

        $total = (int) (clone $base)->count();

        // Count distinct days that have at least one order (active trading days)
        $activeDays = (int) (clone $base)
            ->selectRaw('COUNT(DISTINCT DATE(order_date)) as cnt')
            ->value('cnt');

        $avgPerDay = $activeDays > 0
            ? round($total / $activeDays, 1)
            : 0.0;

        return [
            'total'            => $total,
            'completed'        => $rows['completed']        ?? 0,
            'shipping'         => $rows['shipping']         ?? 0,
            'pending_approval' => $rows['pending approval'] ?? 0,
            'rejected'         => $rows['rejected']         ?? 0,
            'on_hold'          => ($rows['on hold'] ?? 0) + ($rows['credit hold'] ?? 0),
            'open'             => $rows['open']             ?? 0,
            'back_order'       => $rows['back order']       ?? 0,
            'avg_per_day'      => $avgPerDay,
            'active_days'      => $activeDays,
            'open_so'          => $rows['open'] ?? 0,
        ];
    }

    /** @return list<string> */
    private function excludedCustomerIds(): array
    {
        $ids = config('dashboard.excluded_customer_ids', ['CUST102641']);

        return array_values(array_filter(array_map(
            static fn ($id) => strtoupper(trim((string) $id)),
            is_array($ids) ? $ids : [],
        )));
    }

    private function goodsLostInTransitCustomerId(): string
    {
        return strtoupper(trim((string) config(
            'dashboard.goods_lost_in_transit.customer_id',
            'CUST102641',
        )));
    }

    private function goodsLostInTransitLabel(): string
    {
        return (string) config(
            'dashboard.goods_lost_in_transit.label',
            'Goods Lost in Transit',
        );
    }

    /**
     * @param  \Illuminate\Database\Eloquent\Builder<\App\Models\AcumaticaSalesOrder>  $query
     * @return \Illuminate\Database\Eloquent\Builder<\App\Models\AcumaticaSalesOrder>
     */
    private function excludeSpecialCustomers($query)
    {
        $ids = $this->excludedCustomerIds();
        if ($ids !== []) {
            $query->where(function ($q) use ($ids) {
                $q->whereNull('customer_acumatica_id')
                    ->orWhereNotIn('customer_acumatica_id', $ids);
            });
        }

        return $query;
    }

    /**
     * Group orders by day, returning a flat array where each entry is:
     * { day, label, total, completed, shipping, pending_approval, rejected, on_hold }
     *
     * $labelOffset shifts the "label" day for comparison rows so the chart
     * can align current vs previous on the same x-axis position.
     */
    private function dailyTrend(string $dateFrom, string $dateTo, ?string $labelOffset = null, ?User $user = null, ?Request $request = null): array
    {
        $base = $this->excludeSpecialCustomers(
            DataScope::applyOrderScope(
                AcumaticaSalesOrder::query()->salesOrdersOnly(),
                $user,
            ),
        );
        if ($request !== null) {
            $base = $this->applyDashboardFilters($base, $request);
        }
        $rows = $base
            ->selectRaw('DATE(order_date) as day, status, COUNT(*) as cnt')
            ->whereDate('order_date', '>=', $dateFrom)
            ->whereDate('order_date', '<=', $dateTo)
            ->groupByRaw('DATE(order_date), status')
            ->orderByRaw('DATE(order_date)')
            ->get();

        $fillRatesByDay = $this->fillRateQtyByDay($dateFrom, $dateTo, $user, $request);

        // Build a map keyed by day
        $byDay = [];
        foreach ($rows as $row) {
            $day = $row->day;
            if (! isset($byDay[$day])) {
                $fillQty = $fillRatesByDay[$day] ?? ['shipped' => 0.0, 'ordered' => 0.0];
                $byDay[$day] = [
                    'day'              => $day,
                    'total'            => 0,
                    'completed'        => 0,
                    'shipping'         => 0,
                    'pending_approval' => 0,
                    'rejected'         => 0,
                    'on_hold'          => 0,
                    'open'             => 0,
                    'fill_shipped_qty' => $fillQty['shipped'],
                    'fill_ordered_qty' => $fillQty['ordered'],
                    'fill_rate_pct'    => SalesOrderLineFulfillmentDeriver::safeFillRate(
                        $fillQty['shipped'],
                        $fillQty['ordered'],
                    ),
                ];
            }
            $byDay[$day]['total'] += (int) $row->cnt;
            $key = match (strtolower(trim($row->status ?? ''))) {
                'completed'        => 'completed',
                'shipping'         => 'shipping',
                'pending approval' => 'pending_approval',
                'rejected'         => 'rejected',
                'on hold', 'credit hold' => 'on_hold',
                'open'             => 'open',
                default            => null,
            };
            if ($key) {
                $byDay[$day][$key] += (int) $row->cnt;
            }
        }

        // If this is a comparison set, shift the day labels forward by the
        // period length so the chart x-axis aligns with the current period.
        if ($labelOffset !== null) {
            $offsetDays = Carbon::parse($labelOffset)->diffInDays(now()->startOfMonth());
            $result = [];
            foreach (array_values($byDay) as $i => $entry) {
                $entry['day'] = Carbon::parse($entry['day'])->addDays($offsetDays)->toDateString();
                $result[] = $entry;
            }
            return $result;
        }

        // Include days that have fill-rate data but no status breakdown rows.
        foreach ($fillRatesByDay as $day => $fillQty) {
            if (isset($byDay[$day])) {
                continue;
            }

            $byDay[$day] = [
                'day'              => $day,
                'total'            => 0,
                'completed'        => 0,
                'shipping'         => 0,
                'pending_approval' => 0,
                'rejected'         => 0,
                'on_hold'          => 0,
                'open'             => 0,
                'fill_shipped_qty' => $fillQty['shipped'],
                'fill_ordered_qty' => $fillQty['ordered'],
                'fill_rate_pct'    => SalesOrderLineFulfillmentDeriver::safeFillRate(
                    $fillQty['shipped'],
                    $fillQty['ordered'],
                ),
            ];
        }

        ksort($byDay);

        return array_values($byDay);
    }

    /**
     * @return array<string, array{shipped: float, ordered: float}>
     */
    private function fillRateQtyByDay(string $dateFrom, string $dateTo, ?User $user = null, ?Request $request = null): array
    {
        $query = DB::table('acumatica_fill_rate_snapshots as f')
            ->join('acumatica_sales_orders as o', 'f.sales_order_id', '=', 'o.id')
            ->where('o.order_type', AcumaticaSalesOrder::TYPE_SALES_ORDER)
            ->whereDate('o.order_date', '>=', $dateFrom)
            ->whereDate('o.order_date', '<=', $dateTo)
            ->where('f.fill_rate_status', '!=', 'na');

        $excluded = $this->excludedCustomerIds();
        if ($excluded !== []) {
            $query->where(function ($q) use ($excluded) {
                $q->whereNull('o.customer_acumatica_id')
                    ->orWhereNotIn('o.customer_acumatica_id', $excluded);
            });
        }

        if (SalesConsultantScope::appliesTo($user)) {
            $repCode = SalesConsultantScope::repCode($user);
            if ($repCode === null) {
                return [];
            }
            $query->where('o.sales_consultant_rep_code', $repCode);
        }

        if ($request !== null) {
            $this->applyAliasedDashboardFilters($query, $request);
        }

        $rows = $query
            ->selectRaw('DATE(o.order_date) as day')
            ->selectRaw('SUM(f.total_shipped_qty) as shipped')
            ->selectRaw('SUM(f.total_ordered_qty) as ordered')
            ->groupByRaw('DATE(o.order_date)')
            ->get();

        $byDay = [];
        foreach ($rows as $row) {
            $byDay[$row->day] = [
                'shipped' => (float) $row->shipped,
                'ordered' => (float) $row->ordered,
            ];
        }

        return $byDay;
    }

    private function applyDashboardFilters($query, Request $request, bool $applyStatus = true)
    {
        $this->applyLegacyConsultantFallback($query, $request->user());

        $this->applyCustomerFilter($query, $request, customerColumn: 'customer_acumatica_id', nameColumn: 'customer_name');

        if ($applyStatus) {
            $statuses = $this->multiFilterValues($request, 'status');
            if ($statuses !== []) {
                $query->whereIn('status', $statuses);
            }
        }

        $segments = array_map('strtoupper', $this->multiFilterValues($request, 'segment'));
        $hasKp = in_array('KP', $segments, true);
        $hasCs = in_array('CS', $segments, true);
        // KP and CS partition the catalog; selecting both (or neither) means no segment filter.
        if ($hasKp && ! $hasCs) {
            $query->whereHas('customer', fn ($q) => $q->whereRaw("UPPER(TRIM(COALESCE(customer_class, ''))) LIKE 'KP%'"));
        } elseif ($hasCs && ! $hasKp) {
            $query->whereHas('customer', fn ($q) => $q->whereRaw("UPPER(TRIM(COALESCE(customer_class, ''))) NOT LIKE 'KP%'"));
        }

        $brands = $this->multiFilterValues($request, 'brand');
        if ($brands !== []) {
            $query->whereExists(function ($subquery) use ($brands) {
                $subquery->selectRaw('1')
                    ->from('acumatica_sales_order_lines as dashboard_lines')
                    ->join('acumatica_inventory_items as dashboard_items', 'dashboard_items.inventory_id', '=', 'dashboard_lines.inventory_id')
                    ->whereColumn('dashboard_lines.sales_order_id', 'acumatica_sales_orders.id')
                    ->whereIn('dashboard_items.brand', $brands);
            });
        }

        $repCodes = array_map('strtoupper', $this->multiFilterValues($request, 'rep_code'));
        if ($repCodes !== []) {
            $query->whereIn('sales_consultant_rep_code', $repCodes);
        }

        return $query;
    }

    /**
     * Accept multi-select filters as comma-separated strings or arrays
     * (status / status[] / statuses).
     *
     * @return list<string>
     */
    private function multiFilterValues(Request $request, string $key): array
    {
        $raw = $request->input($key);
        if ($raw === null || $raw === '') {
            $plural = $key.'s';
            $raw = $request->input($plural);
        }

        if (is_array($raw)) {
            $values = $raw;
        } else {
            $values = preg_split('/\s*,\s*/', trim((string) $raw), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        }

        return array_values(array_unique(array_filter(array_map(
            static fn ($value) => trim((string) $value),
            $values,
        ), static fn ($value) => $value !== '')));
    }

    /**
     * Multi-select customer IDs (whereIn) or a single free-text needle (LIKE id/name).
     *
     * @param  \Illuminate\Database\Eloquent\Builder|\Illuminate\Database\Query\Builder  $query
     */
    private function applyCustomerFilter($query, Request $request, string $customerColumn, string $nameColumn): void
    {
        $customers = $this->multiFilterValues($request, 'customer');
        if ($customers === []) {
            $customers = $this->multiFilterValues($request, 'customer_id');
        }
        if ($customers === []) {
            return;
        }

        // Multi-select or explicit IDs → exact match on customer_acumatica_id.
        if (count($customers) > 1 || $this->looksLikeCustomerId($customers[0])) {
            $query->whereIn($customerColumn, $customers);

            return;
        }

        // Single free-text search (legacy).
        $needle = $customers[0];
        $query->where(function ($q) use ($needle, $customerColumn, $nameColumn) {
            $q->where($customerColumn, 'like', "%{$needle}%")
                ->orWhere($nameColumn, 'like', "%{$needle}%");
        });
    }

    private function looksLikeCustomerId(string $value): bool
    {
        $v = strtoupper(trim($value));

        return (bool) preg_match('/^CUST\d+/i', $v)
            || (bool) preg_match('/^[A-Z0-9]{4,}$/', $v);
    }

    private function applyLegacyConsultantFallback($query, ?User $user): void
    {
        if (! SalesConsultantScope::appliesTo($user)
            || app(CustomerAttributionService::class)->isMappedOnlyConsultant($user)) {
            return;
        }

        $repCode = SalesConsultantScope::repCode($user);
        $repCode === null
            ? $query->whereRaw('1 = 0')
            : $query->where('sales_consultant_rep_code', $repCode);
    }

    private function applyAliasedDashboardFilters($query, Request $request): void
    {
        $this->applyCustomerFilter($query, $request, customerColumn: 'o.customer_acumatica_id', nameColumn: 'o.customer_name');

        $statuses = $this->multiFilterValues($request, 'status');
        if ($statuses !== []) {
            $query->whereIn('o.status', $statuses);
        }

        $repCodes = array_map('strtoupper', $this->multiFilterValues($request, 'rep_code'));
        if ($repCodes !== []) {
            $query->whereIn('o.sales_consultant_rep_code', $repCodes);
        }

        $segments = array_map('strtoupper', $this->multiFilterValues($request, 'segment'));
        $hasKp = in_array('KP', $segments, true);
        $hasCs = in_array('CS', $segments, true);
        if ($hasKp xor $hasCs) {
            $query->join('acumatica_customers as dashboard_customer', 'dashboard_customer.acumatica_id', '=', 'o.customer_acumatica_id');
            $operator = $hasKp ? 'LIKE' : 'NOT LIKE';
            $query->whereRaw("UPPER(TRIM(COALESCE(dashboard_customer.customer_class, ''))) {$operator} 'KP%'");
        }

        $brands = $this->multiFilterValues($request, 'brand');
        if ($brands !== []) {
            $query->whereExists(function ($subquery) use ($brands) {
                $subquery->selectRaw('1')
                    ->from('acumatica_sales_order_lines as dashboard_lines')
                    ->join('acumatica_inventory_items as dashboard_items', 'dashboard_items.inventory_id', '=', 'dashboard_lines.inventory_id')
                    ->whereColumn('dashboard_lines.sales_order_id', 'o.id')
                    ->whereIn('dashboard_items.brand', $brands);
            });
        }
    }
}
