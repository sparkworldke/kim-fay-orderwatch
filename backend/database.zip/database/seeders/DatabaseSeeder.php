<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            AdminUserSeeder::class,
            RolesPermissionsSeeder::class,
            DepartmentSeeder::class,
            ShippingZoneSeeder::class,
            RouteSeeder::class,
            UserRepCodeSeeder::class,
            CustomerSeeder::class,
        ]);
    }
}
